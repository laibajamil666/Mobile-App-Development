import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../config/firebaseConfig';
import { validateRiphahEmail, generateSapIdFromEmail } from '../utils/validation';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isFocused, setIsFocused] = useState({
    email: false,
    password: false
  });
  const [loginType, setLoginType] = useState('user'); // 'user' or 'admin'

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    // Admin login validation
    if (loginType === 'admin') {
      const adminEmail = 'admin@riphah.edu.pk';
      if (email !== adminEmail) {
        Alert.alert('Error', 'Admin email is incorrect');
        return;
      }
    } else {
      // Student login validation
      if (!validateRiphahEmail(email)) {
        Alert.alert('Error', 'Please use a valid Riphah student email (e.g., john.doe@students.riphah.edu.pk)');
        return;
      }
    }

    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
      let errorMessage = error.message;
      
      // User-friendly error messages
      if (error.code === 'auth/invalid-credential') {
        errorMessage = 'Invalid email or password. Please check your credentials.';
      } else if (error.code === 'auth/user-not-found') {
        errorMessage = `No account found with email: ${email}\n\nPlease sign up first.`;
      } else if (error.code === 'auth/wrong-password') {
        errorMessage = 'Incorrect password. Please try again.';
      } else if (error.code === 'auth/too-many-requests') {
        errorMessage = 'Too many failed attempts. Please try again later.';
      }
      
      Alert.alert('Login Failed', errorMessage);
    }
    setLoading(false);
  };

  const handleFocus = (field) => {
    setIsFocused(prev => ({ ...prev, [field]: true }));
  };

  const handleBlur = (field) => {
    setIsFocused(prev => ({ ...prev, [field]: false }));
  };

  const handleLoginTypeChange = (type) => {
    setLoginType(type);
    setEmail('');
    setPassword('');
    setIsFocused({ email: false, password: false });
  };

  // Quick admin login for development
  const handleQuickAdminLogin = () => {
    setEmail('admin@riphah.edu.pk');
    setPassword('Admin123456');
    setTimeout(() => {
      if (email || password) {
        handleLogin();
      }
    }, 300);
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.content}>
        {/* Header Section */}
        <View style={styles.header}>
          <View style={styles.logoContainer}>
            <View style={styles.logoPlaceholder}>
              <Text style={styles.logoText}>R</Text>
            </View>
          </View>
          <Text style={styles.title}>Welcome to Riphah Portal</Text>
          <Text style={styles.subtitle}>Sign in to access your student dashboard</Text>
        </View>

        {/* Login Type Selector */}
        <View style={styles.loginTypeContainer}>
          <TouchableOpacity
            style={[
              styles.loginTypeButton,
              loginType === 'user' && styles.loginTypeButtonActive
            ]}
            onPress={() => handleLoginTypeChange('user')}
          >
            <Text style={[
              styles.loginTypeText,
              loginType === 'user' && styles.loginTypeTextActive
            ]}>🎓 Student Login</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.loginTypeButton,
              loginType === 'admin' && styles.loginTypeButtonActive
            ]}
            onPress={() => handleLoginTypeChange('admin')}
          >
            <Text style={[
              styles.loginTypeText,
              loginType === 'admin' && styles.loginTypeTextActive
            ]}>👨‍💼 Admin Login</Text>
          </TouchableOpacity>
        </View>

        {/* Form Section */}
        <View style={styles.formContainer}>
          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>
              {loginType === 'admin' ? 'Admin Email' : 'Student Email'}
            </Text>
            <TextInput
              style={[
                styles.input,
                isFocused.email && styles.inputFocused,
                email && styles.inputFilled
              ]}
              placeholder={
                loginType === 'admin' 
                  ? "admin@riphah.edu.pk" 
                  : "john.doe@students.riphah.edu.pk"
              }
              placeholderTextColor="#666"
              value={email}
              onChangeText={setEmail}
              onFocus={() => handleFocus('email')}
              onBlur={() => handleBlur('email')}
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
            />
            {loginType === 'user' && email && !validateRiphahEmail(email) && (
              <Text style={styles.errorText}>Please use valid Riphah student email</Text>
            )}
            {loginType === 'user' && email && validateRiphahEmail(email) && (
              <Text style={styles.infoText}>
                Your SAP ID will be: {generateSapIdFromEmail(email)}
              </Text>
            )}
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>Password</Text>
            <TextInput
              style={[
                styles.input,
                isFocused.password && styles.inputFocused,
                password && styles.inputFilled
              ]}
              placeholder="Enter your password"
              placeholderTextColor="#666"
              value={password}
              onChangeText={setPassword}
              onFocus={() => handleFocus('password')}
              onBlur={() => handleBlur('password')}
              secureTextEntry
              autoComplete="password"
            />
          </View>

          <TouchableOpacity 
            style={[
              styles.loginButton,
              loading && styles.buttonDisabled,
              (!email || !password) && styles.buttonDisabled
            ]} 
            onPress={handleLogin}
            disabled={loading || !email || !password}
          >
            <Text style={styles.loginButtonText}>
              {loading ? (
                <>
                  <Text>🔐 </Text>
                  Signing In...
                </>
              ) : (
                <>
                  <Text>{loginType === 'admin' ? '👨‍💼 ' : '🚀 '}</Text>
                  {loginType === 'admin' ? 'Login as Admin' : 'Login as Student'}
                </>
              )}
            </Text>
          </TouchableOpacity>

          {/* Temporary Admin Login Button (Development Only) */}
          {loginType === 'admin' && (
            <TouchableOpacity
              style={styles.tempAdminButton}
              onPress={handleQuickAdminLogin}
            >
              <Text style={styles.tempAdminButtonText}>🔐 Quick Admin Login (Development)</Text>
            </TouchableOpacity>
          )}

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or</Text>
            <View style={styles.dividerLine} />
          </View>

          {/* Sign Up Link (only for students) */}
          {loginType === 'user' && (
            <View style={styles.signupContainer}>
              <Text style={styles.signupText}>Don't have an account? </Text>
              <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
                <Text style={styles.signupLink}>Create one</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Info Box */}
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Login Information:</Text>
          <Text style={styles.infoText}>
            {loginType === 'admin' 
              ? '• Use admin credentials to access admin dashboard\n• View student statistics and course enrollments'
              : '• Use any text before @students.riphah.edu.pk\n• SAP ID will be automatically generated\n• View timetable, enroll in courses, upload CV'
            }
          </Text>
        </View>

        {/* Development Note */}
        <View style={styles.devNote}>
          <Text style={styles.devNoteText}>💡 Development Mode: Use "Quick Admin Login" for testing</Text>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>Riphah International University</Text>
          <Text style={styles.footerSubtext}>Student Portal v2.0</Text>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f7ff', // Soft light blue background
  },
  content: {
    flex: 1,
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logoContainer: {
    marginBottom: 20,
  },
  logoPlaceholder: {
    width: 80,
    height: 80,
    backgroundColor: '#2c5282', // Deep university blue
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1a365d', // Deep navy blue
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#4a5568', // Medium gray-blue
    textAlign: 'center',
  },
  loginTypeContainer: {
    flexDirection: 'row',
    backgroundColor: '#e6f0ff', // Very light blue
    borderRadius: 12,
    padding: 4,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#c3dafe',
  },
  loginTypeButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  loginTypeButtonActive: {
    backgroundColor: '#2c5282', // Deep university blue
  },
  loginTypeText: {
    color: '#4a5568', // Gray-blue
    fontSize: 14,
    fontWeight: '600',
  },
  loginTypeTextActive: {
    color: 'white',
    fontWeight: 'bold',
  },
  formContainer: {
    backgroundColor: '#f7fafc', // Very light gray-blue
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2d3748', // Dark gray-blue
    marginBottom: 8,
    marginLeft: 4,
  },
  input: {
    backgroundColor: '#edf2f7', // Light gray-blue
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    color: '#1a202c', // Very dark blue
    fontSize: 16,
    fontWeight: '500',
  },
  inputFocused: {
    borderColor: '#3182ce', // Bright blue
    backgroundColor: '#ebf8ff', // Light blue
    shadowColor: '#3182ce',
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  inputFilled: {
    borderColor: '#38a169', // Green
    backgroundColor: '#f0fff4', // Light green
  },
  errorText: {
    color: '#c53030', // Red
    fontSize: 12,
    marginTop: 6,
    marginLeft: 4,
  },
  infoText: {
    color: '#2c5282', // Deep blue
    fontSize: 12,
    marginTop: 6,
    marginLeft: 4,
    fontStyle: 'italic',
  },
  loginButton: {
    backgroundColor: '#2c5282', // Deep university blue
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
  buttonDisabled: {
    backgroundColor: '#a0aec0', // Medium gray
    shadowColor: 'transparent',
  },
  loginButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  tempAdminButton: {
    backgroundColor: '#fffaf0', // Light cream
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#fbd38d', // Light orange
  },
  tempAdminButtonText: {
    color: '#c05621', // Dark orange
    fontSize: 14,
    fontWeight: '600',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#e2e8f0', // Light gray
  },
  dividerText: {
    color: '#718096', // Gray
    paddingHorizontal: 16,
    fontSize: 14,
    fontWeight: '500',
  },
  signupContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  signupText: {
    color: '#718096',
    fontSize: 14,
  },
  signupLink: {
    color: '#2c5282', // Deep blue
    fontSize: 14,
    fontWeight: 'bold',
  },
  infoBox: {
    backgroundColor: '#e6fffa', // Very light teal
    borderRadius: 12,
    padding: 16,
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#b2f5ea', // Light teal border
  },
  infoTitle: {
    color: '#234e52', // Dark teal
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  infoText: {
    color: '#2d3748', // Dark gray-blue
    fontSize: 12,
    lineHeight: 18,
  },
  devNote: {
    backgroundColor: '#fffaf0', // Light cream
    borderRadius: 10,
    padding: 12,
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#fed7d7', // Light red
    alignItems: 'center',
  },
  devNoteText: {
    color: '#c53030', // Red
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
  },
  footer: {
    alignItems: 'center',
    marginTop: 40,
  },
  footerText: {
    color: '#4a5568', // Gray-blue
    fontSize: 14,
    marginBottom: 4,
  },
  footerSubtext: {
    color: '#a0aec0', // Light gray
    fontSize: 12,
  },
});

export default LoginScreen;