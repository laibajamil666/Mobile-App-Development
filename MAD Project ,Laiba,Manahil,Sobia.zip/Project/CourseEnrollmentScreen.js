import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, Animated } from 'react-native';
import { auth, db } from '../config/firebaseConfig';
import { doc, getDoc, updateDoc, setDoc } from 'firebase/firestore';
import { AVAILABLE_COURSES } from '../types/navigation';
import { validateCreditHours, generateSapIdFromEmail } from '../utils/validation';

const CourseEnrollmentScreen = ({ navigation }) => {
  const [selectedCourses, setSelectedCourses] = useState([]);
  const [currentCredits, setCurrentCredits] = useState(0);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const progressAnim = new Animated.Value(0);

  useEffect(() => {
    console.log('🎯 CourseEnrollmentScreen - Component mounted');
    fetchUserData();
  }, []);

  useEffect(() => {
    Animated.timing(progressAnim, {
      toValue: (currentCredits / 20) * 100,
      duration: 500,
      useNativeDriver: false,
    }).start();
  }, [currentCredits]);

  const fetchUserData = async () => {
    const user = auth.currentUser;
    if (user) {
      console.log('📋 CourseEnrollmentScreen - Fetching data for user:', user.uid);
      
      const userDocRef = doc(db, 'students', user.uid);
      
      try {
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists()) {
          const data = userDoc.data();
          console.log('✅ CourseEnrollmentScreen - Data loaded:', {
            courses: data.enrolledCourses?.length || 0,
            credits: data.enrolledCourses?.reduce((total, course) => total + course.credits, 0) || 0,
            sapId: data.sapId
          });
          
          setUserData(data);
          setSelectedCourses(data.enrolledCourses || []);
          setCurrentCredits(data.enrolledCourses?.reduce((total, course) => total + course.credits, 0) || 0);
        } else {
          console.log('⚠️ CourseEnrollmentScreen - No document found, creating default...');
          
          const newUserData = {
            sapId: generateSapIdFromEmail(user.email),
            email: user.email,
            displayName: user.email?.split('@')[0] || 'Student',
            enrolledCourses: [],
            createdAt: new Date().toISOString()
          };
          
          await setDoc(userDocRef, newUserData);
          console.log('✅ CourseEnrollmentScreen - Default document created');
          
          setUserData(newUserData);
          setSelectedCourses([]);
          setCurrentCredits(0);
        }
      } catch (error) {
        console.error('❌ CourseEnrollmentScreen - Error:', error);
        Alert.alert('Error', 'Failed to load course data. Please try again.');
      } finally {
        setIsLoading(false);
      }
    } else {
      console.log('❌ CourseEnrollmentScreen - No user logged in');
      setIsLoading(false);
    }
  };

  const toggleCourse = (course) => {
    const isSelected = selectedCourses.some(c => c.id === course.id);
    
    if (isSelected) {
      const updatedCourses = selectedCourses.filter(c => c.id !== course.id);
      setSelectedCourses(updatedCourses);
      setCurrentCredits(currentCredits - course.credits);
      console.log(`➖ Course removed: ${course.code}, Credits: ${currentCredits - course.credits}`);
    } else {
      if (!validateCreditHours(selectedCourses, course)) {
        Alert.alert('Credit Limit', 'Cannot exceed 20 credit hours');
        return;
      }
      setSelectedCourses([...selectedCourses, course]);
      setCurrentCredits(currentCredits + course.credits);
      console.log(`➕ Course added: ${course.code}, Credits: ${currentCredits + course.credits}`);
    }
  };

  const saveEnrollment = async () => {
    if (selectedCourses.length === 0) {
      Alert.alert('Error', 'Please select at least one course');
      return;
    }

    setLoading(true);
    try {
      const user = auth.currentUser;
      const userDocRef = doc(db, 'students', user.uid);

      console.log('💾 CourseEnrollmentScreen - Saving enrollment:', {
        courses: selectedCourses.length,
        credits: currentCredits,
        user: user.uid
      });

      await updateDoc(userDocRef, {
        enrolledCourses: selectedCourses,
        lastUpdated: new Date().toISOString()
      });

      console.log('✅ CourseEnrollmentScreen - Enrollment saved successfully');
      Alert.alert('Success', '🎉 Courses enrolled successfully!');
      navigation.goBack();
    } catch (error) {
      console.error('❌ CourseEnrollmentScreen - Save error:', error);
      Alert.alert('Error', 'Failed to save enrollment: ' + error.message);
    }
    setLoading(false);
  };

  const isCourseSelected = (course) => {
    return selectedCourses.some(c => c.id === course.id);
  };

  const getProgressColor = () => {
    const percentage = (currentCredits / 20) * 100;
    if (percentage <= 60) return '#38a169';
    if (percentage <= 85) return '#dd6b20';
    return '#c53030';
  };

  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
  });

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading courses...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.logoContainer}>
            <View style={styles.logoPlaceholder}>
              <Text style={styles.logoText}>R</Text>
            </View>
          </View>
          <Text style={styles.title}>Course Enrollment</Text>
          <Text style={styles.subtitle}>Select your courses for the semester</Text>
        </View>
      </View>

      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Credit Progress Card */}
        <View style={styles.progressCard}>
          <View style={styles.progressHeader}>
            <Text style={styles.progressTitle}>Credit Hours</Text>
            <Text style={styles.creditCount}>{currentCredits}/20</Text>
          </View>
          
          <View style={styles.progressBarContainer}>
            <View style={styles.progressBarBackground}>
              <Animated.View 
                style={[
                  styles.progressBarFill,
                  { 
                    width: progressWidth,
                    backgroundColor: getProgressColor()
                  }
                ]} 
              />
            </View>
          </View>

          <View style={styles.progressLabels}>
            <Text style={styles.progressLabel}>0</Text>
            <Text style={styles.progressLabel}>10</Text>
            <Text style={styles.progressLabel}>20</Text>
          </View>

          <View style={styles.statsContainer}>
            <View style={styles.stat}>
              <Text style={styles.statNumber}>{selectedCourses.length}</Text>
              <Text style={styles.statLabel}>Courses</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statNumber}>{currentCredits}</Text>
              <Text style={styles.statLabel}>Credits</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statNumber}>{20 - currentCredits}</Text>
              <Text style={styles.statLabel}>Remaining</Text>
            </View>
          </View>
        </View>

        {/* Available Courses */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Available Courses</Text>
          <Text style={styles.sectionSubtitle}>
            Tap to select/deselect courses (Max: 20 credits)
          </Text>

          <View style={styles.coursesGrid}>
            {AVAILABLE_COURSES.map((course) => {
              const isSelected = isCourseSelected(course);
              return (
                <TouchableOpacity
                  key={course.id}
                  style={[
                    styles.courseCard,
                    isSelected && styles.courseCardSelected
                  ]}
                  onPress={() => toggleCourse(course)}
                >
                  <View style={styles.courseHeader}>
                    <Text style={styles.courseCode}>{course.code}</Text>
                    <View style={[
                      styles.selectionIndicator,
                      isSelected && styles.selectionIndicatorSelected
                    ]}>
                      {isSelected && <Text style={styles.checkmark}>✓</Text>}
                    </View>
                  </View>
                  
                  <Text style={styles.courseName} numberOfLines={2}>
                    {course.name}
                  </Text>
                  
                  <View style={styles.courseFooter}>
                    <View style={styles.creditBadge}>
                      <Text style={styles.creditText}>{course.credits} CR</Text>
                    </View>
                    <Text style={[
                      styles.courseStatus,
                      isSelected && styles.courseStatusSelected
                    ]}>
                      {isSelected ? 'Selected' : 'Available'}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionsContainer}>
          <TouchableOpacity 
            style={[
              styles.saveButton,
              (selectedCourses.length === 0 || loading) && styles.buttonDisabled
            ]} 
            onPress={saveEnrollment}
            disabled={selectedCourses.length === 0 || loading}
          >
            <Text style={styles.saveButtonText}>
              {loading ? '💾 Saving...' : `💾 Save Enrollment (${selectedCourses.length} courses)`}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.backButtonText}>🔙 Back to Profile</Text>
          </TouchableOpacity>
        </View>
        
        {/* Info Box */}
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>Important Notes:</Text>
          <Text style={styles.infoText}>
            • Maximum 20 credit hours allowed per semester{'\n'}
            • Course selection cannot be changed after deadline{'\n'}
            • Ensure course prerequisites are met{'\n'}
            • Contact advisor for any enrollment issues
          </Text>
        </View>

        {/* Debug Info */}
        {__DEV__ && (
          <View style={styles.debugInfo}>
            <Text style={styles.debugTitle}>Debug Info:</Text>
            <Text style={styles.debugText}>
              User: {auth.currentUser?.email}{'\n'}
              Courses: {selectedCourses.length}{'\n'}
              Credits: {currentCredits}{'\n'}
              SAP ID: {userData?.sapId}
            </Text>
          </View>
        )}

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>Riphah International University</Text>
          <Text style={styles.footerSubtext}>Course Enrollment System</Text>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f7ff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f7ff',
  },
  loadingText: {
    fontSize: 18,
    color: '#4a5568',
    fontWeight: '500',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 24,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  headerContent: {
    alignItems: 'center',
  },
  logoContainer: {
    marginBottom: 16,
  },
  logoPlaceholder: {
    width: 70,
    height: 70,
    backgroundColor: '#2c5282',
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  logoText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1a365d',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#4a5568',
    textAlign: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  progressCard: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 24,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  progressTitle: {
    color: '#1a365d',
    fontSize: 18,
    fontWeight: 'bold',
  },
  creditCount: {
    color: '#2c5282',
    fontSize: 20,
    fontWeight: 'bold',
  },
  progressBarContainer: {
    marginBottom: 8,
  },
  progressBarBackground: {
    height: 10,
    backgroundColor: '#e2e8f0',
    borderRadius: 5,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 5,
    transition: 'all 0.3s ease',
  },
  progressLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  progressLabel: {
    color: '#718096',
    fontSize: 12,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  stat: {
    alignItems: 'center',
  },
  statNumber: {
    color: '#1a202c',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#4a5568',
    fontSize: 12,
    fontWeight: '500',
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  sectionTitle: {
    color: '#1a365d',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: '#4a5568',
    fontSize: 14,
    marginBottom: 20,
  },
  coursesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  courseCard: {
    width: '48%',
    backgroundColor: '#f7fafc',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  courseCardSelected: {
    borderColor: '#2c5282',
    backgroundColor: '#e6f0ff',
    transform: [{ scale: 1.02 }],
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  courseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  courseCode: {
    color: '#2c5282',
    fontSize: 14,
    fontWeight: 'bold',
    flex: 1,
  },
  selectionIndicator: {
    width: 22,
    height: 22,
    borderWidth: 2,
    borderColor: '#cbd5e0',
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },
  selectionIndicatorSelected: {
    backgroundColor: '#2c5282',
    borderColor: '#2c5282',
  },
  checkmark: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  courseName: {
    color: '#1a202c',
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 12,
    lineHeight: 18,
  },
  courseFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  creditBadge: {
    backgroundColor: '#e6fffa',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#b2f5ea',
  },
  creditText: {
    color: '#234e52',
    fontSize: 12,
    fontWeight: 'bold',
  },
  courseStatus: {
    color: '#718096',
    fontSize: 10,
    fontWeight: '500',
  },
  courseStatusSelected: {
    color: '#2c5282',
    fontWeight: 'bold',
  },
  actionsContainer: {
    marginBottom: 20,
  },
  saveButton: {
    backgroundColor: '#2c5282',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
  buttonDisabled: {
    backgroundColor: '#a0aec0',
    shadowColor: 'transparent',
  },
  saveButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#f7fafc',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  backButtonText: {
    color: '#4a5568',
    fontSize: 14,
    fontWeight: '500',
  },
  infoBox: {
    backgroundColor: '#e6fffa',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#b2f5ea',
  },
  infoTitle: {
    color: '#234e52',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  infoText: {
    color: '#2d3748',
    fontSize: 12,
    lineHeight: 18,
  },
  debugInfo: {
    backgroundColor: '#fff5f5',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#fed7d7',
  },
  debugTitle: {
    color: '#c53030',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  debugText: {
    color: '#2d3748',
    fontSize: 12,
    lineHeight: 16,
    fontFamily: 'monospace',
  },
  footer: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 30,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  footerText: {
    color: '#4a5568',
    fontSize: 14,
    marginBottom: 4,
  },
  footerSubtext: {
    color: '#a0aec0',
    fontSize: 12,
  },
});

export default CourseEnrollmentScreen;