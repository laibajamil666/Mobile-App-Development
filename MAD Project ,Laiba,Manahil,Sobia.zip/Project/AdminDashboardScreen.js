import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, ActivityIndicator, Image } from 'react-native';
import { auth, db } from '../config/firebaseConfig';
import { signOut } from 'firebase/auth';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { BarChart, PieChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';

const screenWidth = Dimensions.get('window').width;

const AdminDashboardScreen = ({ navigation }) => {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalCourses: 0,
    avgCoursesPerStudent: 0,
    popularCourses: []
  });

  useEffect(() => {
    fetchStudentsData();
  }, []);

  const fetchStudentsData = async () => {
    try {
      const studentsRef = collection(db, 'students');
      const querySnapshot = await getDocs(studentsRef);
      
      const studentsData = [];
      let totalCoursesCount = 0;
      const courseFrequency = {};

      querySnapshot.forEach((doc) => {
        const studentData = doc.data();
        const courses = studentData.enrolledCourses || [];
        
        studentsData.push({
          id: doc.id,
          ...studentData,
          courseCount: courses.length
        });

        totalCoursesCount += courses.length;

        // Count course frequency
        courses.forEach(course => {
          courseFrequency[course.code] = (courseFrequency[course.code] || 0) + 1;
        });
      });

      // Calculate popular courses
      const popularCourses = Object.entries(courseFrequency)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([course, count]) => ({ course, count }));

      setStudents(studentsData);
      setStats({
        totalStudents: studentsData.length,
        totalCourses: totalCoursesCount,
        avgCoursesPerStudent: studentsData.length > 0 ? (totalCoursesCount / studentsData.length).toFixed(1) : 0,
        popularCourses
      });
    } catch (error) {
      console.error('Error fetching students:', error);
      Alert.alert('Error', 'Failed to fetch student data');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: async () => {
            try {
              await signOut(auth);
            } catch (error) {
              Alert.alert('Logout Failed', error.message);
            }
          }
        }
      ]
    );
  };

  const getCourseDistributionData = () => {
    const distribution = { '0': 0, '1-2': 0, '3-4': 0, '5+': 0 };
    
    students.forEach(student => {
      const count = student.courseCount;
      if (count === 0) distribution['0']++;
      else if (count <= 2) distribution['1-2']++;
      else if (count <= 4) distribution['3-4']++;
      else distribution['5+']++;
    });

    return {
      labels: ['0', '1-2', '3-4', '5+'],
      datasets: [{
        data: Object.values(distribution),
        colors: [
          (opacity = 1) => `rgba(239, 68, 68, ${opacity})`,
          (opacity = 1) => `rgba(245, 158, 11, ${opacity})`,
          (opacity = 1) => `rgba(59, 130, 246, ${opacity})`,
          (opacity = 1) => `rgba(16, 185, 129, ${opacity})`
        ]
      }]
    };
  };

  const getPopularCoursesData = () => {
    const data = stats.popularCourses.map(item => item.count);
    const labels = stats.popularCourses.map(item => item.course);
    
    return {
      labels,
      datasets: [{
        data,
        colors: data.map((_, index) => {
          const colors = ['#2c5282', '#3182ce', '#38a169', '#dd6b20', '#c53030'];
          return (opacity = 1) => `${colors[index % colors.length]}${Math.floor(opacity * 255).toString(16).padStart(2, '0')}`;
        })
      }]
    };
  };

  const chartConfig = {
    backgroundColor: '#f0f7ff',
    backgroundGradientFrom: '#ffffff',
    backgroundGradientTo: '#f7fafc',
    decimalPlaces: 0,
    color: (opacity = 1) => `rgba(44, 82, 130, ${opacity})`,
    labelColor: (opacity = 1) => `rgba(26, 54, 93, ${opacity})`,
    style: {
      borderRadius: 16,
    },
    propsForDots: {
      r: '6',
      strokeWidth: '2',
      stroke: '#2c5282'
    },
    propsForLabels: {
      fontSize: 12,
      fontWeight: '500',
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2c5282" />
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.logoContainer}>
            <View style={styles.logoPlaceholder}>
              <Text style={styles.logoText}>A</Text>
            </View>
          </View>
          <View style={styles.adminBadge}>
            <Text style={styles.adminBadgeText}>👨‍💼 ADMIN DASHBOARD</Text>
          </View>
          <Text style={styles.title}>Admin Analytics Center</Text>
          <Text style={styles.subtitle}>Student Statistics & Enrollment Insights</Text>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>👥</Text>
            <Text style={styles.statNumber}>{stats.totalStudents}</Text>
            <Text style={styles.statLabel}>Total Students</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>📚</Text>
            <Text style={styles.statNumber}>{stats.totalCourses}</Text>
            <Text style={styles.statLabel}>Total Courses</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statIcon}>📊</Text>
            <Text style={styles.statNumber}>{stats.avgCoursesPerStudent}</Text>
            <Text style={styles.statLabel}>Avg per Student</Text>
          </View>
        </View>

        {/* Course Distribution Chart */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Course Distribution</Text>
          <Text style={styles.sectionSubtitle}>Number of courses per student</Text>
          
          <View style={styles.chartContainer}>
            <BarChart
              data={getCourseDistributionData()}
              width={screenWidth - 80}
              height={220}
              chartConfig={chartConfig}
              style={styles.chart}
              showValuesOnTopOfBars
            />
          </View>
        </View>

        {/* Popular Courses Chart */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Popular Courses</Text>
          <Text style={styles.sectionSubtitle}>Most enrolled courses</Text>
          
          <View style={styles.chartContainer}>
            <PieChart
              data={getPopularCoursesData().datasets[0].data.map((value, index) => ({
                name: stats.popularCourses[index]?.course || `Course ${index + 1}`,
                population: value,
                color: getPopularCoursesData().datasets[0].colors[index](1),
                legendFontColor: '#4a5568',
                legendFontSize: 12
              }))}
              width={screenWidth - 80}
              height={200}
              chartConfig={chartConfig}
              accessor="population"
              backgroundColor="transparent"
              paddingLeft="15"
              absolute
            />
          </View>
        </View>

        {/* Student List */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Student Details</Text>
            <TouchableOpacity onPress={fetchStudentsData} style={styles.refreshButton}>
              <Text style={styles.refreshText}>🔄 Refresh</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.tableHeader}>
            <Text style={[styles.tableHeaderText, styles.tableCol1]}>SAP ID</Text>
            <Text style={[styles.tableHeaderText, styles.tableCol2]}>Courses</Text>
            <Text style={[styles.tableHeaderText, styles.tableCol3]}>Details</Text>
          </View>
          
          {students.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateIcon}>📊</Text>
              <Text style={styles.emptyStateText}>No students found</Text>
            </View>
          ) : (
            students.map((student, index) => (
              <View key={student.id} style={[
                styles.tableRow,
                index % 2 === 0 ? styles.tableRowEven : styles.tableRowOdd
              ]}>
                <Text style={[styles.tableCell, styles.tableCol1]}>{student.sapId}</Text>
                <View style={[styles.tableCell, styles.tableCol2]}>
                  <Text style={styles.courseCountText}>{student.courseCount}</Text>
                  <Text style={styles.courseCountLabel}>courses</Text>
                </View>
                <View style={[styles.tableCell, styles.tableCol3]}>
                  <TouchableOpacity 
                    style={styles.detailsButton}
                    onPress={() => Alert.alert(
                      'Student Details',
                      `SAP ID: ${student.sapId}\nEmail: ${student.email}\nCourses Enrolled: ${student.courseCount}\nMember Since: ${student.createdAt ? new Date(student.createdAt).toLocaleDateString() : 'N/A'}`,
                      [{ text: 'OK', style: 'default' }]
                    )}
                  >
                    <Text style={styles.detailsButtonText}>👁️ View</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))
          )}
        </View>

        {/* Course Details Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Course Enrollment Details</Text>
          
          {stats.popularCourses.map((item, index) => (
            <View key={index} style={styles.courseItem}>
              <View style={styles.courseInfo}>
                <Text style={styles.courseRank}>#{index + 1}</Text>
                <Text style={styles.courseCode}>{item.course}</Text>
                <Text style={styles.courseCountBadge}>{item.count} students</Text>
              </View>
              <View style={styles.progressBar}>
                <View 
                  style={[
                    styles.progressFill,
                    { 
                      width: `${(item.count / stats.totalStudents) * 100}%`,
                      backgroundColor: ['#2c5282', '#3182ce', '#38a169', '#dd6b20', '#c53030'][index]
                    }
                  ]} 
                />
              </View>
            </View>
          ))}
        </View>

        {/* Actions */}
        <View style={styles.actionsContainer}>
          <TouchableOpacity 
            style={styles.generateReportButton}
            onPress={() => Alert.alert(
              'Report Generated',
              '📊 Student enrollment report has been generated successfully!',
              [{ text: 'OK', style: 'default' }]
            )}
          >
            <Text style={styles.generateReportText}>📥 Generate Report</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.logoutButton}
            onPress={handleLogout}
          >
            <View style={styles.logoutButtonContent}>
              <Image 
                source={require('../../assets/logout.png')}  // Update this path according to your file structure
                style={styles.logoutIcon}
                resizeMode="contain"
              />
              <Text style={styles.logoutButtonText}>Logout</Text>
            </View>
          </TouchableOpacity>
        </View>
        
        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>Riphah International University</Text>
          <Text style={styles.footerSubtext}>Admin Portal v2.0</Text>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f7ff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f7ff',
  },
  loadingText: {
    color: '#4a5568',
    marginTop: 12,
    fontSize: 16,
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 24,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  headerContent: {
    alignItems: 'center',
  },
  logoContainer: {
    marginBottom: 16,
  },
  logoPlaceholder: {
    width: 70,
    height: 70,
    backgroundColor: '#2c5282',
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  logoText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
  },
  adminBadge: {
    backgroundColor: '#e6f0ff',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: '#c3dafe',
  },
  adminBadgeText: {
    color: '#2c5282',
    fontSize: 14,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1a365d',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: '#4a5568',
    textAlign: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 6,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  statIcon: {
    fontSize: 24,
    marginBottom: 8,
    color: '#2c5282',
  },
  statNumber: {
    color: '#1a365d',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#4a5568',
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
  },
  section: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    color: '#1a365d',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  sectionSubtitle: {
    color: '#4a5568',
    fontSize: 14,
    marginBottom: 16,
  },
  chartContainer: {
    backgroundColor: '#f7fafc',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#e6f0ff',
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#c3dafe',
  },
  tableHeaderText: {
    color: '#2c5282',
    fontSize: 12,
    fontWeight: 'bold',
  },
  tableCol1: {
    flex: 2,
  },
  tableCol2: {
    flex: 1,
    textAlign: 'center',
  },
  tableCol3: {
    flex: 1,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    padding: 12,
    borderRadius: 12,
    marginBottom: 6,
    alignItems: 'center',
  },
  tableRowEven: {
    backgroundColor: '#f7fafc',
  },
  tableRowOdd: {
    backgroundColor: '#ffffff',
  },
  tableCell: {
    color: '#1a202c',
    fontSize: 14,
  },
  courseCountText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2c5282',
  },
  courseCountLabel: {
    fontSize: 10,
    color: '#718096',
  },
  detailsButton: {
    backgroundColor: '#e6f0ff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#c3dafe',
  },
  detailsButtonText: {
    color: '#2c5282',
    fontSize: 12,
    fontWeight: '500',
  },
  emptyState: {
    alignItems: 'center',
    padding: 20,
  },
  emptyStateIcon: {
    fontSize: 48,
    marginBottom: 12,
    color: '#cbd5e0',
  },
  emptyStateText: {
    color: '#718096',
    fontSize: 16,
    fontWeight: '500',
  },
  refreshButton: {
    backgroundColor: '#e6f0ff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#c3dafe',
  },
  refreshText: {
    color: '#2c5282',
    fontSize: 14,
    fontWeight: '500',
  },
  courseItem: {
    marginBottom: 12,
  },
  courseInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  courseRank: {
    backgroundColor: '#2c5282',
    color: 'white',
    width: 24,
    height: 24,
    borderRadius: 12,
    textAlign: 'center',
    lineHeight: 24,
    fontWeight: 'bold',
    marginRight: 12,
  },
  courseCode: {
    color: '#1a202c',
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
  },
  courseCountBadge: {
    backgroundColor: '#e6fffa',
    color: '#234e52',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    fontSize: 12,
    borderWidth: 1,
    borderColor: '#b2f5ea',
  },
  progressBar: {
    height: 6,
    backgroundColor: '#e2e8f0',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  actionsContainer: {
    marginBottom: 20,
  },
  generateReportButton: {
    backgroundColor: '#2c5282',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
  generateReportText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  logoutButton: {
    backgroundColor: '#fff5f5',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#fed7d7',
  },
  logoutButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoutIcon: {
    width: 20,
    height: 20,
    marginRight: 8,
    tintColor: '#c53030', // Optional: to match the red theme
  },
  logoutButtonText: {
    color: '#c53030',
    fontSize: 16,
    fontWeight: 'bold',
  },
  footer: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 30,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  footerText: {
    color: '#4a5568',
    fontSize: 14,
    marginBottom: 4,
  },
  footerSubtext: {
    color: '#a0aec0',
    fontSize: 12,
  },
});

export default AdminDashboardScreen;