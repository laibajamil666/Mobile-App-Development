import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../config/firebaseConfig';
import { validateRiphahEmail, generateSapIdFromEmail } from '../utils/validation';

const SignupScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isFocused, setIsFocused] = useState({
    email: false,
    password: false,
    confirmPassword: false
  });

  const handleSignup = async () => {
    console.log('🚀 SignupScreen - Starting signup process');
    
    if (!email || !password || !confirmPassword) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    if (!validateRiphahEmail(email)) {
      Alert.alert('Error', 'Please use a valid Riphah student email (e.g., john.doe@students.riphah.edu.pk)');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    if (password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters long');
      return;
    }

    setLoading(true);
    try {
      console.log('🔐 SignupScreen - Creating user with email:', email);
      
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      console.log('✅ SignupScreen - User created, UID:', user.uid);
      
      // Generate SAP ID from email (any prefix allowed)
      const sapId = generateSapIdFromEmail(email);
      console.log('🎓 SignupScreen - Generated SAP ID:', sapId);

      // Create COMPLETE user document in Firestore
      const userDocRef = doc(db, 'students', user.uid);
      const userData = {
        sapId: sapId,
        email: email,
        displayName: email.split('@')[0] || 'Student',
        enrolledCourses: [],
        cvInfo: null,  // Important: Initialize cvInfo
        createdAt: new Date().toISOString(),  // Use ISO string for consistency
        lastLogin: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      console.log('💾 SignupScreen - Creating Firestore document:', userData);
      
      await setDoc(userDocRef, userData);

      console.log('✅ SignupScreen - User document created successfully in Firestore');
      
      Alert.alert(
        'Success', 
        `🎉 Account created successfully!\n\n📝 Your SAP ID: ${sapId}\n📧 Email: ${email}\n\nYou can now login with your email.`,
        [
          { 
            text: 'Continue to Login', 
            onPress: () => navigation.navigate('Login')
          }
        ]
      );
      
    } catch (error) {
      console.error('❌ SignupScreen - Error:', error);
      
      let errorMessage = error.message;
      
      // User-friendly error messages
      if (error.code === 'auth/email-already-in-use') {
        errorMessage = 'This email is already registered. Please login instead.';
      } else if (error.code === 'auth/invalid-email') {
        errorMessage = 'Invalid email format. Please check your email.';
      } else if (error.code === 'auth/weak-password') {
        errorMessage = 'Password is too weak. Please use a stronger password.';
      } else if (error.code === 'auth/operation-not-allowed') {
        errorMessage = 'Email/password accounts are not enabled. Please contact support.';
      } else if (error.code === 'auth/network-request-failed') {
        errorMessage = 'Network error. Please check your internet connection.';
      }
      
      Alert.alert('Signup Failed', errorMessage);
    }
    setLoading(false);
  };

  const handleFocus = (field) => {
    setIsFocused(prev => ({ ...prev, [field]: true }));
  };

  const handleBlur = (field) => {
    setIsFocused(prev => ({ ...prev, [field]: false }));
  };

  const getPasswordStrength = () => {
    if (password.length === 0) return { strength: 0, color: '#a0aec0', text: '' };
    if (password.length < 6) return { strength: 33, color: '#c53030', text: 'Weak' };
    if (password.length < 8) return { strength: 66, color: '#d69e2e', text: 'Medium' };
    return { strength: 100, color: '#38a169', text: 'Strong' };
  };

  const passwordStrength = getPasswordStrength();

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.content}>
          {/* Header Section */}
          <View style={styles.header}>
            <View style={styles.logoContainer}>
              <View style={styles.logoPlaceholder}>
                <Text style={styles.logoText}>R</Text>
              </View>
            </View>
            <Text style={styles.title}>Join Riphah</Text>
            <Text style={styles.subtitle}>Create your student account</Text>
          </View>

          {/* Form Section */}
          <View style={styles.formContainer}>
            {/* Email Input */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Student Email</Text>
              <TextInput
                style={[
                  styles.input,
                  isFocused.email && styles.inputFocused,
                  email && validateRiphahEmail(email) && styles.inputValid,
                  email && !validateRiphahEmail(email) && styles.inputError
                ]}
                placeholder="john.doe@students.riphah.edu.pk" 
                placeholderTextColor="#666"
                value={email}
                onChangeText={setEmail}
                onFocus={() => handleFocus('email')}
                onBlur={() => handleBlur('email')}
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
              />
              {email && !validateRiphahEmail(email) && (
                <Text style={styles.errorText}>Please use valid Riphah email format</Text>
              )}
              {email && validateRiphahEmail(email) && (
                <Text style={styles.successText}>✓ Valid Riphah email</Text>
              )}
              {email && validateRiphahEmail(email) && (
                <Text style={styles.infoText}>
                  Your SAP ID will be: {generateSapIdFromEmail(email)}
                </Text>
              )}
            </View>

            {/* Password Input */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Password</Text>
              <TextInput
                style={[
                  styles.input,
                  isFocused.password && styles.inputFocused,
                  password && styles.inputFilled
                ]}
                placeholder="Create a strong password"
                placeholderTextColor="#666"
                value={password}
                onChangeText={setPassword}
                onFocus={() => handleFocus('password')}
                onBlur={() => handleBlur('password')}
                secureTextEntry
                autoComplete="password-new"
              />
              {password.length > 0 && (
                <View style={styles.passwordStrengthContainer}>
                  <View style={styles.strengthBar}>
                    <View 
                      style={[
                        styles.strengthFill,
                        { 
                          width: `${passwordStrength.strength}%`,
                          backgroundColor: passwordStrength.color
                        }
                      ]} 
                    />
                  </View>
                  <Text style={[styles.strengthText, { color: passwordStrength.color }]}>
                    {passwordStrength.text}
                  </Text>
                </View>
              )}
              <Text style={styles.helperText}>Minimum 6 characters required</Text>
            </View>

            {/* Confirm Password Input */}
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Confirm Password</Text>
              <TextInput
                style={[
                  styles.input,
                  isFocused.confirmPassword && styles.inputFocused,
                  confirmPassword && styles.inputFilled,
                  confirmPassword && password !== confirmPassword && styles.inputError,
                  confirmPassword && password === confirmPassword && styles.inputValid
                ]}
                placeholder="Re-enter your password"
                placeholderTextColor="#666"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                onFocus={() => handleFocus('confirmPassword')}
                onBlur={() => handleBlur('confirmPassword')}
                secureTextEntry
                autoComplete="password-new"
              />
              {confirmPassword && password !== confirmPassword && (
                <Text style={styles.errorText}>Passwords do not match</Text>
              )}
              {confirmPassword && password === confirmPassword && (
                <Text style={styles.successText}>✓ Passwords match</Text>
              )}
            </View>

            {/* Sign Up Button */}
            <TouchableOpacity 
              style={[
                styles.signupButton,
                loading && styles.buttonDisabled,
                (!email || !password || !confirmPassword || password !== confirmPassword || !validateRiphahEmail(email)) && styles.buttonDisabled
              ]} 
              onPress={handleSignup}
              disabled={loading || !email || !password || !confirmPassword || password !== confirmPassword || !validateRiphahEmail(email)}
            >
              <Text style={styles.signupButtonText}>
                {loading ? (
                  <>
                    <Text>⏳ </Text>
                    Creating Account...
                  </>
                ) : (
                  <>
                    <Text>🎓 </Text>
                    Create Student Account
                  </>
                )}
              </Text>
            </TouchableOpacity>

            {/* Divider */}
            <View style={styles.divider}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>or</Text>
              <View style={styles.dividerLine} />
            </View>

            {/* Login Link */}
            <View style={styles.loginContainer}>
              <Text style={styles.loginText}>Already have an account? </Text>
              <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                <Text style={styles.loginLink}>Sign in</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Features List */}
          <View style={styles.featuresContainer}>
            <Text style={styles.featuresTitle}>What you'll get:</Text>
            <View style={styles.featureItem}>
              <Text style={styles.featureIcon}>📚</Text>
              <Text style={styles.featureText}>Course enrollment</Text>
            </View>
            <View style={styles.featureItem}>
              <Text style={styles.featureIcon}>🕒</Text>
              <Text style={styles.featureText}>Personal timetable</Text>
            </View>
            <View style={styles.featureItem}>
              <Text style={styles.featureIcon}>📄</Text>
              <Text style={styles.featureText}>CV management</Text>
            </View>
            <View style={styles.featureItem}>
              <Text style={styles.featureIcon}>💫</Text>
              <Text style={styles.featureText}>Motivational quotes</Text>
            </View>
            <View style={styles.featureItem}>
              <Text style={styles.featureIcon}>🔒</Text>
              <Text style={styles.featureText}>Secure data storage</Text>
            </View>
            <View style={styles.featureItem}>
              <Text style={styles.featureIcon}>🔄</Text>
              <Text style={styles.featureText}>Persistent login data</Text>
            </View>
          </View>

          {/* Info Box */}
          <View style={styles.infoBox}>
            <Text style={styles.infoTitle}>Important Information:</Text>
            <Text style={styles.infoText}>
              • Your SAP ID is automatically generated from your email{'\n'}
              • All data is securely stored and persists across logins{'\n'}
              • You can upload CV and enroll in courses{'\n'}
              • Contact support if you face any issues
            </Text>
          </View>

          {/* Debug Info (Development Only) */}
          {__DEV__ && (
            <View style={styles.debugInfo}>
              <Text style={styles.debugTitle}>Debug Mode:</Text>
              <Text style={styles.debugText}>
                Email: {email || '(empty)'}{'\n'}
                Valid Email: {validateRiphahEmail(email) ? 'Yes' : 'No'}{'\n'}
                SAP ID: {generateSapIdFromEmail(email) || 'N/A'}{'\n'}
                Passwords Match: {password && confirmPassword ? (password === confirmPassword ? 'Yes' : 'No') : 'N/A'}
              </Text>
            </View>
          )}

          {/* Footer */}
          <View style={styles.footer}>
            <Text style={styles.footerText}>Riphah International University</Text>
            <Text style={styles.footerSubtext}>Student Portal v2.0</Text>
            <Text style={styles.versionText}>Data Persistence Enabled</Text>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f7ff',
  },
  scrollContent: {
    flexGrow: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoContainer: {
    marginBottom: 20,
  },
  logoPlaceholder: {
    width: 80,
    height: 80,
    backgroundColor: '#2c5282',
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1a365d',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#4a5568',
    textAlign: 'center',
  },
  formContainer: {
    backgroundColor: '#f7fafc',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
    marginBottom: 24,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2d3748',
    marginBottom: 8,
    marginLeft: 4,
  },
  input: {
    backgroundColor: '#edf2f7',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    color: '#1a202c',
    fontSize: 16,
    fontWeight: '500',
  },
  inputFocused: {
    borderColor: '#3182ce',
    backgroundColor: '#ebf8ff',
    shadowColor: '#3182ce',
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  inputFilled: {
    borderColor: '#38a169',
    backgroundColor: '#f0fff4',
  },
  inputValid: {
    borderColor: '#38a169',
  },
  inputError: {
    borderColor: '#c53030',
  },
  errorText: {
    color: '#c53030',
    fontSize: 12,
    marginTop: 6,
    marginLeft: 4,
  },
  successText: {
    color: '#38a169',
    fontSize: 12,
    marginTop: 6,
    marginLeft: 4,
  },
  infoText: {
    color: '#2c5282',
    fontSize: 12,
    marginTop: 6,
    marginLeft: 4,
    fontStyle: 'italic',
  },
  helperText: {
    color: '#718096',
    fontSize: 12,
    marginTop: 6,
    marginLeft: 4,
  },
  passwordStrengthContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  strengthBar: {
    flex: 1,
    height: 4,
    backgroundColor: '#cbd5e0',
    borderRadius: 2,
    marginRight: 12,
    overflow: 'hidden',
  },
  strengthFill: {
    height: '100%',
    borderRadius: 2,
    transition: 'all 0.3s ease',
  },
  strengthText: {
    fontSize: 12,
    fontWeight: '600',
    minWidth: 40,
  },
  signupButton: {
    backgroundColor: '#2c5282',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
    shadowColor: '#2c5282',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
  buttonDisabled: {
    backgroundColor: '#a0aec0',
    shadowColor: 'transparent',
  },
  signupButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#e2e8f0',
  },
  dividerText: {
    color: '#718096',
    paddingHorizontal: 16,
    fontSize: 14,
    fontWeight: '500',
  },
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loginText: {
    color: '#718096',
    fontSize: 14,
  },
  loginLink: {
    color: '#2c5282',
    fontSize: 14,
    fontWeight: 'bold',
  },
  featuresContainer: {
    backgroundColor: '#e6fffa',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#b2f5ea',
  },
  featuresTitle: {
    color: '#234e52',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureIcon: {
    fontSize: 16,
    marginRight: 12,
    width: 24,
    color: '#2c5282',
  },
  featureText: {
    color: '#2d3748',
    fontSize: 14,
    fontWeight: '500',
  },
  infoBox: {
    backgroundColor: '#ebf8ff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#bee3f8',
  },
  infoTitle: {
    color: '#2c5282',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
    textAlign: 'center',
  },
  infoText: {
    color: '#2d3748',
    fontSize: 13,
    lineHeight: 20,
  },
  debugInfo: {
    backgroundColor: '#fffaf0',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#fbd38d',
  },
  debugTitle: {
    color: '#c05621',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  debugText: {
    color: '#2d3748',
    fontSize: 12,
    lineHeight: 16,
    fontFamily: 'monospace',
  },
  footer: {
    alignItems: 'center',
  },
  footerText: {
    color: '#4a5568',
    fontSize: 14,
    marginBottom: 4,
  },
  footerSubtext: {
    color: '#a0aec0',
    fontSize: 12,
    marginBottom: 4,
  },
  versionText: {
    color: '#38a169',
    fontSize: 11,
    fontStyle: 'italic',
  },
});

export default SignupScreen;