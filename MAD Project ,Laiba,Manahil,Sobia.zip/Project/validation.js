// Email validation for Riphah student emails - Accepts ANY text before @
export const validateRiphahEmail = (email) => {
  if (!email) return false;
  
  // Trim and convert to lowercase
  const trimmedEmail = email.trim().toLowerCase();
  
  // Accepts any characters before @students.riphah.edu.pk
  const regex = /^.+@students\.riphah\.edu\.pk$/;
  return regex.test(trimmedEmail);
};

// Validate admin email
export const validateAdminEmail = (email) => {
  if (!email) return false;
  
  const trimmedEmail = email.trim().toLowerCase();
  const adminEmails = [
    'admin@riphah.edu.pk',
    'administrator@riphah.edu.pk',
    'superadmin@riphah.edu.pk'
  ];
  
  return adminEmails.includes(trimmedEmail);
};

// Generate consistent 5-digit SAP ID from any email prefix
export const generateSapIdFromEmail = (email) => {
  if (!email) return '10000';
  
  const trimmedEmail = email.trim().toLowerCase();
  const username = trimmedEmail.split('@')[0];
  
  // Create a deterministic hash from the username
  let hash = 0;
  for (let i = 0; i < username.length; i++) {
    const char = username.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = Math.abs(hash & hash); // Convert to positive 32-bit integer
  }
  
  // Ensure we get a 5-digit number (10000-99999)
  const sapIdNumber = (hash % 90000) + 10000;
  return sapIdNumber.toString();
};

// Extract SAP ID (compatible with both old and new systems)
export const extractSapId = (email) => {
  if (!email) return '10000';
  
  const trimmedEmail = email.trim().toLowerCase();
  
  // If email matches old format (digits@...), extract digits
  const oldFormatMatch = trimmedEmail.match(/^(\d+)@students\.riphah\.edu\.pk$/);
  if (oldFormatMatch && oldFormatMatch[1]) {
    const digits = oldFormatMatch[1];
    return digits.padStart(5, '0').slice(-5); // Ensure 5 digits
  }
  
  // Otherwise generate from email
  return generateSapIdFromEmail(trimmedEmail);
};

// Generate display name from email
export const getDisplayNameFromEmail = (email) => {
  if (!email) return 'Student';
  
  const username = email.split('@')[0];
  
  // Capitalize first letter of each word if space separated
  if (username.includes('.')) {
    return username.split('.')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }
  
  // Capitalize first letter
  return username.charAt(0).toUpperCase() + username.slice(1);
};

// Validate password strength
export const validatePassword = (password) => {
  return password && password.length >= 6;
};

// Validate credit hours
export const validateCreditHours = (selectedCourses, courseToAdd) => {
  const currentCredits = selectedCourses.reduce((total, course) => total + course.credits, 0);
  const newTotal = currentCredits + courseToAdd.credits;
  return newTotal <= 20;
};

// Generate random student email for testing
export const generateRandomStudentEmail = () => {
  const prefixes = [
    'john.doe', 'jane.smith', 'alex.wilson', 'sarah.jones', 
    'mike.brown', 'emily.davis', 'david.miller', 'lisa.taylor',
    'robert.clark', 'amanda.lewis', 'student', 'user', 'test'
  ];
  
  const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const randomNumber = Math.floor(Math.random() * 100);
  
  return `${randomPrefix}${randomNumber}@students.riphah.edu.pk`;
};