// firebase.js - Firebase Configuration
import { initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB0myGXEYJR12gdkG7XpiYwbgovTbx07UY",
  authDomain: "resort-8c353.firebaseapp.com",
  projectId: "resort-8c353",
  storageBucket: "resort-8c353.firebasestorage.app",
  messagingSenderId: "289469443750",
  appId: "1:289469443750:web:e25f78f14ad44844c18e67"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});

// Initialize Firestore
const db = getFirestore(app);

export { auth, db };