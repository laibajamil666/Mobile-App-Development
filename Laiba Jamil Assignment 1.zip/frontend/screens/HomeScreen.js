import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Button, TextInput } from 'react-native';
import Header from '../components/Header';
import CategoryCard from '../components/CategoryCard';
import { GlobalStyles, Colors, Typography } from '../styles/GlobalStyles';
import AsyncStorage from '@react-native-async-storage/async-storage';

const categories = [
  {
    id: 1,
    name: 'Winter',
    image: require('../../assets/winter_collection.jpg'),
    screen: 'Winter'
  },
  {
    id: 2,
    name: 'Summer',
    image: require('../../assets/summer_collection.jpg'),
    screen: 'Summer'
  },
  {
    id: 3,
    name: 'Perfumes',
    image: require('../../assets/perfumes_collection.jpg'),
    screen: 'Perfumes'
  },
  {
    id: 4,
    name: 'Sale',
    image: require('../../assets/sale_collection.jpg'),
    screen: 'Sale',
    subtitle: 'Up to 50% OFF'
  },
];

export default function HomeScreen({ navigation }) {
  // AsyncStorage States
  const [keyInput, setKeyInput] = useState('');
  const [valueInput, setValueInput] = useState('');
  const [storeMsg, setStoreMsg] = useState('');
  const [fetchMsg, setFetchMsg] = useState('');
  const [deleteMsg, setDeleteMsg] = useState('');
  const [fetchedValue, setFetchedValue] = useState('');
  const [allData, setAllData] = useState([]);
  const [showStorageSection, setShowStorageSection] = useState(false);

  // ✅ 1. Store Data
  const storeData = async () => {
    if (!keyInput || !valueInput) {
      setStoreMsg('⚠️ Please enter both key and value.');
      return;
    }
    try {
      await AsyncStorage.setItem(keyInput, valueInput);
      setStoreMsg(`✅ Stored successfully for key "${keyInput}"`);
      setKeyInput('');
      setValueInput('');
    } catch (e) {
      console.log(e);
      setStoreMsg('❌ Failed to store data.');
    }
  };

  // ✅ 2. Fetch Data
  const fetchData = async () => {
    if (!keyInput) {
      setFetchMsg('⚠️ Please enter a key to fetch data.');
      return;
    }
    try {
      const value = await AsyncStorage.getItem(keyInput);
      if (value !== null) {
        setFetchedValue(value);
        setFetchMsg(`🔍 Data found for key "${keyInput}"`);
      } else {
        setFetchedValue('');
        setFetchMsg('⚠️ No data found for this key.');
      }
    } catch (e) {
      console.log(e);
      setFetchMsg('❌ Failed to fetch data.');
    }
  };

  // ✅ 3. Remove Data
  const removeData = async () => {
    if (!keyInput) {
      setDeleteMsg('⚠️ Please enter a key to delete data.');
      return;
    }
    try {
      await AsyncStorage.removeItem(keyInput);
      setFetchedValue('');
      setDeleteMsg(`🗑️ Data removed for key "${keyInput}"`);
      setKeyInput('');
      setValueInput('');
    } catch (e) {
      console.log(e);
      setDeleteMsg('❌ Failed to delete data.');
    }
  };

  // 🆕 4. Show All Saved Data
  const showAllData = async () => {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const stores = await AsyncStorage.multiGet(keys);
      setAllData(stores);
    } catch (e) {
      console.log(e);
    }
  };

  // 🆕 5. Clear All Messages
  const clearMessages = () => {
    setStoreMsg('');
    setFetchMsg('');
    setDeleteMsg('');
    setFetchedValue('');
  };

  return (
    <View style={GlobalStyles.container}>
      <Header title="Fashion Store" showCartIcon={true} navigation={navigation} />
      <ScrollView style={GlobalStyles.scrollView}>
        <Text style={GlobalStyles.welcomeText}>Discover Your Style</Text>
        <Text style={[Typography.body, GlobalStyles.textCenter, { marginBottom: 20 }]}>
          Premium Fashion Collection
        </Text>
        
        {/* Categories Section */}
        <View style={GlobalStyles.categoriesContainer}>
          {categories.map((category) => (
            <CategoryCard
              key={category.id}
              category={category}
              onPress={() => navigation.navigate(category.screen)}
            />
          ))}
        </View>

        {/* AsyncStorage Section Toggle Button */}
        <View style={{ marginVertical: 20, alignItems: 'center' }}>
          <Button
            title={showStorageSection ? "Hide Storage Section" : "Show Storage Section"}
            onPress={() => {
              setShowStorageSection(!showStorageSection);
              clearMessages();
            }}
            color={Colors.primary || '#007AFF'}
          />
        </View>

        {/* AsyncStorage Section */}
        {showStorageSection && (
          <View style={styles.storageSection}>
            <Text style={styles.storageHeading}>📦 AsyncStorage Demo</Text>

            {/* Input fields */}
            <TextInput
              style={styles.input}
              placeholder="Enter key (e.g., userToken)"
              value={keyInput}
              onChangeText={setKeyInput}
            />
            <TextInput
              style={styles.input}
              placeholder="Enter value (e.g., 12345)"
              value={valueInput}
              onChangeText={setValueInput}
            />

            {/* Buttons Row 1 */}
            <View style={styles.buttonRow}>
              <View style={styles.buttonContainer}>
                <Button title="Store Data" onPress={storeData} color="#ff914d" />
              </View>
              <View style={styles.buttonContainer}>
                <Button title="Fetch Data" onPress={fetchData} color="#ff914d" />
              </View>
            </View>

            {/* Buttons Row 2 */}
            <View style={styles.buttonRow}>
              <View style={styles.buttonContainer}>
                <Button title="Remove Data" onPress={removeData} color="#ff914d" />
              </View>
              <View style={styles.buttonContainer}>
                <Button title="Show All Data" onPress={showAllData} color="#4caf50" />
              </View>
            </View>

            {/* Messages */}
            {storeMsg ? <Text style={styles.msg}>{storeMsg}</Text> : null}
            {fetchMsg ? <Text style={styles.msg}>{fetchMsg}</Text> : null}
            {deleteMsg ? <Text style={styles.msg}>{deleteMsg}</Text> : null}
            
            {/* Fetched Value */}
            {fetchedValue ? (
              <Text style={styles.value}>Fetched Value: {fetchedValue}</Text>
            ) : null}

            {/* All Saved Data */}
            {allData.length > 0 && (
              <View style={{ marginTop: 10 }}>
                <Text style={styles.allDataHeading}>🧾 All Saved Data:</Text>
                {allData.map(([key, value], index) => (
                  <Text key={index} style={styles.value}>
                    🔑 {key} : {value}
                  </Text>
                ))}
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  storageSection: {
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 10,
    marginHorizontal: 10,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#e9ecef',
  },
  storageHeading: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
    color: '#2c3e50',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 10,
    padding: 10,
    borderRadius: 8,
    backgroundColor: 'white',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  buttonContainer: {
    flex: 1,
    marginHorizontal: 5,
  },
  msg: {
    marginTop: 5,
    fontSize: 14,
    color: '#333',
    fontStyle: 'italic',
    textAlign: 'center',
  },
  value: {
    marginTop: 5,
    fontSize: 14,
    fontWeight: '600',
    color: '#111',
    textAlign: 'center',
  },
  allDataHeading: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
    color: '#2c3e50',
  },
});